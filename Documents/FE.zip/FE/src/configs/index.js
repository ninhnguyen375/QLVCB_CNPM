export const DEFAULT_URL = 'http://localhost:5000'
