export const MODULE_NAME = 'FRONT_PAGE'
