import React, { Component } from 'react'
import './styles.less'

class Header extends Component {
  render () {
    return (
      <div className='header'>
        <a href='/' className='left'>
          <img
            alt='logo'
            src={require('../../../assets/images/logo.png')}
            height={55}
          />
        </a>
      </div>
    )
  }
}

export default Header
