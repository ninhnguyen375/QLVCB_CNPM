import React, { Component } from 'react'
import Index from '../../frontpage'

class Home extends Component {
  render () {
    return (
      <div>
        <Index />
      </div>
    )
  }
}

export default Home
