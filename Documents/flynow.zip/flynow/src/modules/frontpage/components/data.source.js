import React from 'react'
export const Nav00DataSource = {
  wrapper: { className: 'header0 home-page-wrapper' },
  page: { className: 'home-page' },
  logo: {
    className: 'header0-logo',
    children: require('../../../assets/images/logo.png')
  },
  Menu: {
    className: 'header0-menu',
    children: [
      {
        name: 'item0',
        className: 'header0-item',
        visible: 'ALL',
        children: {
          href: '/',
          children: [{ children: 'HOME', name: 'text' }]
        }
      },
      {
        name: 'item1',
        className: 'header0-item',
        visible: 'UNSIGNINED',
        children: {
          href: '#/login',
          children: [{ children: 'LOGIN', name: 'text' }]
        }
      },
      {
        name: 'item2',
        className: 'header0-item',
        visible: 'UNSIGNINED',
        children: {
          href: '#',
          children: [{ children: 'SIGN UP', name: 'text' }]
        }
      },
      {
        name: 'item3',
        className: 'header0-item',
        visible: 'SIGNINED',
        children: {
          href: '#/dashboard',
          children: [{ children: 'DASHBOARD', name: 'text' }]
        }
      }
    ]
  },
  mobileMenu: { className: 'header0-mobile-menu' }
}
export const Banner01DataSource = {
  wrapper: { className: 'banner0', style: { backgroundImage: `url(${require('../../../assets/images/wall2.jpg')})` } },
  textWrapper: { className: 'banner0-text-wrapper' },
  title: {
    className: 'banner0-title',
    children: <img src={require('../../../assets/images/logo.png')} width='100%' alt='logo' />
  },
  content: {
    className: 'banner0-content k16e6w2on7n-editor_css',
    children: (
      <>
        <p>FLY NOW, GET YOUR TICKET NOW</p>
      </>
    )
  },
  button: { className: 'banner0-button', children: 'Find Flights' }
}
export const Content00DataSource = {
  wrapper: { className: 'home-page-wrapper content0-wrapper' },
  page: { className: 'home-page content0' },
  OverPack: { playScale: 0.3, className: '' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'title',
        children: (
          <>
            <p>WHY CHOOSED?</p>
          </>
        )
      }
    ]
  },
  childWrapper: {
    className: 'content0-block-wrapper',
    children: [
      {
        name: 'block0',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/WBnVOjtIlGWbzyQivuyq.png'
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: (
                <>
                  <p>Quick and convenience payment</p>
                </>
              )
            },
            {
              name: 'content',
              children: (
                <>
                  <p>Easy and trust.</p>
                </>
              )
            }
          ]
        }
      },
      {
        name: 'block1',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/YPMsLQuCEXtuEkmXTTdk.png'
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: (
                <>
                  <p>Quality</p>
                </>
              )
            },
            {
              name: 'content',
              children: (
                <>
                  <p>Leading the world in quality.</p>
                </>
              )
            }
          ]
        }
      },
      {
        name: 'block2',
        className: 'content0-block',
        md: 8,
        xs: 24,
        children: {
          className: 'content0-block-item',
          children: [
            {
              name: 'image',
              className: 'content0-block-icon',
              children:
                'https://zos.alipayobjects.com/rmsportal/EkXWVvAaFJKCzhMmQYiX.png'
            },
            {
              name: 'title',
              className: 'content0-block-title',
              children: (
                <>
                  <p>Customer</p>
                </>
              )
            },
            {
              name: 'content',
              children: (
                <>
                  <p>
                    The rate of customers using the service increased rapidly.
                  </p>
                </>
              )
            }
          ]
        }
      }
    ]
  }
}
export const Content50DataSource = {
  wrapper: { className: 'home-page-wrapper content5-wrapper' },
  page: { className: 'home-page content5' },
  OverPack: { playScale: 0.3, className: '' },
  titleWrapper: {
    className: 'title-wrapper',
    children: [
      {
        name: 'title',
        children: (
          <>
            <p>Flight Tickets</p>
          </>
        ),
        className: 'title-h1'
      },
      {
        name: 'content',
        className: 'title-content',
        children: (
          <>
            <p>Choose the flight ticket that suits you best.</p>
          </>
        )
      }
    ]
  },
  block: {
    className: 'content5-img-wrapper',
    gutter: 16,
    children: [
      {
        name: 'block0',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block1',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block2',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block3',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block4',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block5',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block6',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      },
      {
        name: 'block7',
        className: 'block',
        md: 6,
        xs: 24,
        children: {
          wrapper: { className: 'content5-block-content' },
          img: {
            children:
              'https://res.flynow.vn/minprice/SGN-PQC.jpg'
          },
          content: {
            children: (
              <div>
                <h4>Ho Chi Minh - Phu Quoc</h4>
                <p>Departure date 2019-10-28</p>
              </div>
            )
          }
        }
      }
    ]
  }
}
export const Footer10DataSource = {
  wrapper: { className: 'home-page-wrapper footer1-wrapper' },
  OverPack: { className: 'footer1', playScale: 0.2 },
  block: {
    className: 'home-page',
    gutter: 0,
    children: [
      {
        name: 'block0',
        xs: 24,
        md: 6,
        className: 'block',
        title: {
          className: 'logo',
          children: require('../../../assets/images/logo.png')
        },
        childWrapper: {
          className: 'slogan',
          children: [
            {
              name: 'content0',
              children: 'Animation specification and components of Ant Design.'
            }
          ]
        }
      },
      {
        name: 'block1',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'product' },
        childWrapper: {
          children: [
            { name: 'link0', href: '#', children: 'product' },
            { name: 'link1', href: '#', children: 'product' },
            { name: 'link2', href: '#', children: 'product' },
            { name: 'link3', href: '#', children: 'product' }
          ]
        }
      },
      {
        name: 'block2',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'product' },
        childWrapper: {
          children: [
            { href: '#', name: 'link0', children: 'FAQ' },
            { href: '#', name: 'link1', children: 'product' }
          ]
        }
      },
      {
        name: 'block3',
        xs: 24,
        md: 6,
        className: 'block',
        title: { children: 'product' },
        childWrapper: {
          children: [
            { href: '#', name: 'link0', children: 'product' },
            { href: '#', name: 'link1', children: 'product' }
          ]
        }
      }
    ]
  },
  copyrightWrapper: { className: 'copyright-wrapper' },
  copyrightPage: { className: 'home-page' },
  copyright: {
    className: 'copyright',
    children: (
      <>
        <span>©2019 by Flynow&nbsp;All Rights Reserved</span>
      </>
    )
  }
}
