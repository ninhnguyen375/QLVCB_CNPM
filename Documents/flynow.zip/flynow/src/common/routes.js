import React, { Component } from 'react'
import { Route, Switch } from 'react-router'
import UnderContruct from '../pages/UnderContruct'
import LoginPage from '../pages/LoginPage'
import HomePage from '../pages/HomePage'
import Dashboard from '../pages/Dashboard'
import PageNotFound from '../pages/PageNotFound'

export default class Routes extends Component {
  render () {
    const { store } = this.props
    const { user } = store.getState()
    console.log('DEBUGER: user', user)
    if (!user || !user.user || !user.user.id) {
      return (
        <>
          <Switch>
            <Route key='home' path='/' exact component={HomePage} />
            <Route key='login' path='/login' exact component={LoginPage} />
            <Route key='null' path='*' component={PageNotFound} />
          </Switch>
        </>
      )
    }
    if (user.user.role === 0) {
      return (
        <>
          <Switch>
            <Route key='home' path='/' exact component={HomePage} />
            <Route key='dashboard' path='/dashboard' exact component={Dashboard} />
            <Route key='null' path='*' component={PageNotFound} />
          </Switch>
        </>
      )
    }

    return <Route path='*' component={UnderContruct} />
  }
}
