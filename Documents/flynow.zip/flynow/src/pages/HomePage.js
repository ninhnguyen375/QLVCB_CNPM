import React, { Component } from 'react'
import Home from '../modules/home/components/Home'

class HomePage extends Component {
  render () {
    return (
      <div>
        <Home />
      </div>
    )
  }
}
export default HomePage
