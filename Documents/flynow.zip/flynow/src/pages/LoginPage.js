import React, { Component } from 'react'
import LoginForm from '../modules/user/containers/LoginForm'
import wall1 from '../assets/images/wall1.jpg'

class LoginPage extends Component {
  render () {
    const { history } = this.props
    return (
      <div style={{
        width: '100vw',
        height: '100vh',
        backgroundImage: `url(${wall1})`,
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat'
      }}
      >
        <div style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          width: 310,
          transform: 'translate(-50%, -50%)',
          boxShadow: '0 0 25px 1px black'
        }}
        >
          <LoginForm history={history} />
        </div>
      </div>
    )
  }
}
export default LoginPage
