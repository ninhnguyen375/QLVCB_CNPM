import React, { Component } from 'react'
import Lottie from '../libraries/Lottie.js'
import Header from '../modules/home/components/Header.js'

class PageNotFound extends Component {
  render () {
    return (
      <div style={{
        width: '100vw',
        height: '100vh'
      }}
      >
        <Header />
        <Lottie
          options={{
            animationData: require('../assets/animations/404-page.json')
          }}
          height='70%'
        />
      </div>
    )
  }
}

export default PageNotFound
